
package com.cg.ibs.loanmgmt.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.services.BankAdminService;
import com.cg.ibs.loanmgmt.services.VerifyLoanService;

@Controller
@Scope("session")
public class BankAdminController {
	@Autowired
	private BankAdminService bankAdminService;
	@Autowired
	private VerifyLoanService verifyLoanService;

	BankAdmins bankAdmin = new BankAdmins();

	@RequestMapping(method = RequestMethod.GET, value = "/bankAdmin")
	public ModelAndView loginRole(@RequestParam("userId") String userId) {
		ModelAndView modelAndView = new ModelAndView();
		bankAdmin = bankAdminService.getBankAdmin(userId);
		modelAndView.addObject("loginVerified", "Welcome " + bankAdmin.getAdminId());
		modelAndView.setViewName("loggedinBankAdminPage");
		return modelAndView;
	}

	@RequestMapping(value = "/verifyLoan")
	public ModelAndView viewPendingLoans() {
		System.out.println("fth");
		List<LoanMaster> pendingLoans = verifyLoanService.getPendingLoanList();
		System.out.println("ftru");
		return new ModelAndView("verifyLoan", "pendingLoans", pendingLoans);
	}

	// public ModelAndView
}
