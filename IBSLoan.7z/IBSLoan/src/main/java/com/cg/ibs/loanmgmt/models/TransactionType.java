package com.cg.ibs.loanmgmt.models;

public enum TransactionType {
		CREDIT, DEBIT;
}
