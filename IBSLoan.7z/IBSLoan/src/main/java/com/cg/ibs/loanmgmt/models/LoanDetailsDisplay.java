package com.cg.ibs.loanmgmt.models;

import java.io.Serializable;
import java.math.BigDecimal;

public class LoanDetailsDisplay {

	private BigDecimal emiAmount;
	private BigDecimal principle;
	private BigDecimal interest;

	public BigDecimal getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(BigDecimal emiAmount) {
		this.emiAmount = emiAmount;
	}

	public BigDecimal getPrinciple() {
		return principle;
	}

	public void setPrinciple(BigDecimal principle) {
		this.principle = principle;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public LoanDetailsDisplay(BigDecimal emiAmount, BigDecimal principle, BigDecimal interest) {
		super();
		this.emiAmount = emiAmount;
		this.principle = principle;
		this.interest = interest;
	}

}
